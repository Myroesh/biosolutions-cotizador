const appState = {
  quotation: {
    number: "",
    date: "",
    client: "",
    attention: "",
    city: "",
    validity: "15 días",
    paymentTerms: "",
    notes: ""
  },
  items: [],
  selectedItemId: null
};

function createEmptyItem() {
  return {
    id: crypto.randomUUID(),
    title: "Nuevo equipo",
    brand: "",
    model: "",
    origin: "",
    warranty: "",
    price: "",
    showPrice: false,
    subtitle: "",
    descriptionLong: "",
    highlights: [],
    specs: [],
    uses: [],
    accessories: [],
    advantages: [],
    imageSrc: ""
  };
}

function getSelectedItem() {
  return appState.items.find(item => item.id === appState.selectedItemId) || null;
}

function setSelectedItem(id) {
  appState.selectedItemId = id;
  renderAll();
}

function addItem() {
  const item = createEmptyItem();
  appState.items.push(item);
  appState.selectedItemId = item.id;
  renderAll();
}

function duplicateSelectedItem() {
  const item = getSelectedItem();
  if (!item) return;

  const clone = structuredClone(item);
  clone.id = crypto.randomUUID();
  clone.title = `${item.title} (copia)`;
  appState.items.push(clone);
  appState.selectedItemId = clone.id;
  renderAll();
}

function deleteSelectedItem() {
  const id = appState.selectedItemId;
  if (!id) return;

  appState.items = appState.items.filter(item => item.id !== id);
  appState.selectedItemId = appState.items.length ? appState.items[0].id : null;
  renderAll();
}

function resetQuotation() {
  appState.quotation = {
    number: "",
    date: "",
    client: "",
    attention: "",
    city: "",
    validity: "15 días",
    paymentTerms: "",
    notes: ""
  };
  appState.items = [];
  appState.selectedItemId = null;
  addItem();
}

function formatPrice(value) {
  if (value === null || value === undefined || value === "") return "";
  return `Bs. ${value}`;
}

function escapeHtml(str) {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function nl2br(text) {
  return escapeHtml(text || "").replace(/\n/g, "<br>");
}

function bindQuotationFields() {
  const mappings = {
    qNumber: "number",
    qDate: "date",
    qClient: "client",
    qAttention: "attention",
    qCity: "city",
    qValidity: "validity",
    qPaymentTerms: "paymentTerms",
    qNotes: "notes"
  };

  Object.entries(mappings).forEach(([id, key]) => {
    const el = document.getElementById(id);
    if (!el) return;

    el.addEventListener("input", () => {
      appState.quotation[key] = el.value;
      renderPreview();
    });
  });
}

function populateQuotationFields() {
  const q = appState.quotation;
  document.getElementById("qNumber").value = q.number;
  document.getElementById("qDate").value = q.date;
  document.getElementById("qClient").value = q.client;
  document.getElementById("qAttention").value = q.attention;
  document.getElementById("qCity").value = q.city;
  document.getElementById("qValidity").value = q.validity;
  document.getElementById("qPaymentTerms").value = q.paymentTerms;
  document.getElementById("qNotes").value = q.notes;
}

function bindItemMainFields() {
  const map = [
    ["itemTitle", "title"],
    ["itemBrand", "brand"],
    ["itemModel", "model"],
    ["itemOrigin", "origin"],
    ["itemWarranty", "warranty"],
    ["itemPrice", "price"],
    ["itemSubtitle", "subtitle"],
    ["itemDescriptionLong", "descriptionLong"],
    ["itemImageUrl", "imageSrc"]
  ];

  map.forEach(([id, key]) => {
    const el = document.getElementById(id);
    if (!el) return;

    el.addEventListener("input", (e) => {
      const item = getSelectedItem();
      if (!item) return;
      item[key] = e.target.value;
      renderAll();
    });
  });

  const showPrice = document.getElementById("itemShowPrice");
  if (showPrice) {
    showPrice.addEventListener("change", (e) => {
      const item = getSelectedItem();
      if (!item) return;
      item.showPrice = e.target.checked;
      renderPreview();
    });
  }

  const imageUpload = document.getElementById("itemImageUpload");
  if (imageUpload) {
    imageUpload.addEventListener("change", (e) => {
      const item = getSelectedItem();
      if (!item) return;

      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = () => {
        item.imageSrc = reader.result;
        document.getElementById("itemImageUrl").value = "";
        renderAll();
      };
      reader.readAsDataURL(file);
    });
  }
}

function populateItemFields() {
  const item = getSelectedItem();
  const empty = !item;

  const setValue = (id, value = "") => {
    const el = document.getElementById(id);
    if (el) el.value = value;
  };

  setValue("itemTitle", empty ? "" : item.title);
  setValue("itemBrand", empty ? "" : item.brand);
  setValue("itemModel", empty ? "" : item.model);
  setValue("itemOrigin", empty ? "" : item.origin);
  setValue("itemWarranty", empty ? "" : item.warranty);
  setValue("itemPrice", empty ? "" : item.price);
  setValue("itemSubtitle", empty ? "" : item.subtitle);
  setValue("itemDescriptionLong", empty ? "" : item.descriptionLong);
  setValue("itemImageUrl", empty ? "" : (item.imageSrc && !item.imageSrc.startsWith("data:") ? item.imageSrc : ""));

  const showPrice = document.getElementById("itemShowPrice");
  if (showPrice) showPrice.checked = empty ? false : item.showPrice;
}

function renderItemsList() {
  const container = document.getElementById("itemsList");
  if (!container) return;

  container.innerHTML = "";

  appState.items.forEach((item, index) => {
    const div = document.createElement("div");
    div.className = `item-card ${item.id === appState.selectedItemId ? "active" : ""}`;
    div.innerHTML = `
      <strong>${escapeHtml(item.title || `Equipo ${index + 1}`)}</strong>
      <span>${escapeHtml(item.brand || "")} ${escapeHtml(item.model || "")}</span>
    `;
    div.addEventListener("click", () => setSelectedItem(item.id));
    container.appendChild(div);
  });
}

function renderSimpleListEditor(containerId, items, type) {
  const container = document.getElementById(containerId);
  if (!container) return;

  container.innerHTML = "";

  items.forEach((value, index) => {
    const row = document.createElement("div");
    row.className = "editor-row";
    row.innerHTML = `
      <input type="text" value="${String(value).replace(/"/g, "&quot;")}" />
      <div class="row-actions">
        <button class="btn btn-danger btn-small" type="button">Eliminar</button>
      </div>
    `;

    row.querySelector("input").addEventListener("input", (e) => {
      const item = getSelectedItem();
      if (!item) return;
      item[type][index] = e.target.value;
      renderPreview();
    });

    row.querySelector("button").addEventListener("click", () => {
      const item = getSelectedItem();
      if (!item) return;
      item[type].splice(index, 1);
      renderEditors();
      renderPreview();
    });

    container.appendChild(row);
  });
}

function renderSpecsEditor() {
  const item = getSelectedItem();
  const container = document.getElementById("specsEditor");
  if (!container) return;

  container.innerHTML = "";
  if (!item) return;

  item.specs.forEach((row, index) => {
    const div = document.createElement("div");
    div.className = "editor-row";
    div.innerHTML = `
      <input type="text" placeholder="Parámetro" value="${String(row.param || "").replace(/"/g, "&quot;")}" />
      <textarea placeholder="Detalle">${row.value || ""}</textarea>
      <div class="row-actions">
        <button class="btn btn-danger btn-small" type="button">Eliminar</button>
      </div>
    `;

    const paramInput = div.querySelector("input");
    const valueTextarea = div.querySelector("textarea");
    const removeBtn = div.querySelector("button");

    paramInput.addEventListener("input", (e) => {
      item.specs[index].param = e.target.value;
      renderPreview();
    });

    valueTextarea.addEventListener("input", (e) => {
      item.specs[index].value = e.target.value;
      renderPreview();
    });

    removeBtn.addEventListener("click", () => {
      item.specs.splice(index, 1);
      renderEditors();
      renderPreview();
    });

    container.appendChild(div);
  });
}

function renderEditors() {
  const item = getSelectedItem();

  renderSimpleListEditor("highlightsEditor", item ? item.highlights : [], "highlights");
  renderSpecsEditor();
  renderSimpleListEditor("usesEditor", item ? item.uses : [], "uses");
  renderSimpleListEditor("accessoriesEditor", item ? item.accessories : [], "accessories");
  renderSimpleListEditor("advantagesEditor", item ? item.advantages : [], "advantages");
}

function buildItemPage(item) {
  return `
    <section class="preview-page">
      <div class="left-band"></div>
      <div class="preview-content">
        <section class="preview-hero">
          <div>
            <img src="/static/logo_biosolutions.png" alt="BioSolutions" class="preview-logo" />
          </div>
          <div class="doc-chip">
            <span class="label">Documento</span>
            <span class="value">Ficha técnica</span>
          </div>
        </section>

        <section class="title-card">
          <span class="eyebrow">Equipo médico / laboratorio</span>
          <h1 class="doc-title">${escapeHtml(item.title || "")}</h1>
          <p class="subtitle">${escapeHtml(item.subtitle || "")}</p>

          <div class="meta-grid">
            <div class="meta"><span class="k">Marca</span><span class="v">${escapeHtml(item.brand || "")}</span></div>
            <div class="meta"><span class="k">Modelo</span><span class="v">${escapeHtml(item.model || "")}</span></div>
            <div class="meta"><span class="k">Origen</span><span class="v">${escapeHtml(item.origin || "")}</span></div>
            <div class="meta"><span class="k">Garantía</span><span class="v">${escapeHtml(item.warranty || "")}</span></div>
          </div>

          ${item.showPrice ? `
            <div class="price-box">
              <div class="meta">
                <span class="k">Precio referencial</span>
                <span class="v">${escapeHtml(formatPrice(item.price))}</span>
              </div>
            </div>
          ` : ""}
        </section>

        <section class="main-grid">
          <div>
            <div class="card">
              <h3 class="section-title">Descripción del equipo</h3>
              <p class="preview-text">${escapeHtml(item.descriptionLong || "")}</p>

              ${item.highlights.length ? `
                <h3 class="section-title">Características destacadas</h3>
                <ul class="clean">
                  ${item.highlights.map(h => `<li>${escapeHtml(h)}</li>`).join("")}
                </ul>
              ` : ""}

              ${item.specs.length ? `
                <h3 class="section-title">Especificaciones técnicas</h3>
                <table class="spec-table">
                  <thead>
                    <tr>
                      <th style="width:38%">Parámetro</th>
                      <th>Detalle</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${item.specs.map(s => `
                      <tr>
                        <td>${escapeHtml(s.param || "")}</td>
                        <td>${nl2br(s.value || "")}</td>
                      </tr>
                    `).join("")}
                  </tbody>
                </table>
              ` : ""}
            </div>
          </div>

          <div>
            <div class="card">
              <h3 class="section-title">Imagen del equipo</h3>
              <div class="image-box">
                ${item.imageSrc
                  ? `<img src="${item.imageSrc}" alt="${escapeHtml(item.title || "")}">`
                  : `Sin imagen`
                }
              </div>

              ${item.uses.length ? `
                <h3 class="section-title" style="margin-top:16px;">Aplicaciones / usos</h3>
                <div class="badge-row">
                  ${item.uses.map(u => `<span class="badge">${escapeHtml(u)}</span>`).join("")}
                </div>
              ` : ""}

              ${item.accessories.length ? `
                <h3 class="section-title" style="margin-top:16px;">Contenido / accesorios</h3>
                <ul class="clean">
                  ${item.accessories.map(a => `<li>${escapeHtml(a)}</li>`).join("")}
                </ul>
              ` : ""}

              ${item.advantages.length ? `
                <h3 class="section-title" style="margin-top:16px;">Ventajas principales</h3>
                <ul class="clean">
                  ${item.advantages.map(v => `<li>${escapeHtml(v)}</li>`).join("")}
                </ul>
              ` : ""}
            </div>
          </div>
        </section>
      </div>
    </section>
  `;
}

function buildTotalPage() {
  const total = appState.items.reduce((sum, item) => {
    const n = parseFloat(String(item.price).replace(/,/g, "")) || 0;
    return sum + n;
  }, 0);

  return `
    <section class="preview-page">
      <div class="left-band"></div>
      <div class="preview-content">
        <section class="preview-hero">
          <div>
            <img src="/static/logo_biosolutions.png" alt="BioSolutions" class="preview-logo" />
          </div>
          <div class="doc-chip">
            <span class="label">Documento</span>
            <span class="value">Resumen final</span>
          </div>
        </section>

        <section class="title-card">
          <span class="eyebrow">Cotización consolidada</span>
          <h1 class="doc-title">${escapeHtml(appState.quotation.client || "Cliente")}</h1>
          <p class="subtitle">
            Número: ${escapeHtml(appState.quotation.number || "")}
            ${appState.quotation.date ? ` | Fecha: ${escapeHtml(appState.quotation.date)}` : ""}
          </p>

          <div class="meta-grid">
            <div class="meta"><span class="k">Atención</span><span class="v">${escapeHtml(appState.quotation.attention || "")}</span></div>
            <div class="meta"><span class="k">Ciudad</span><span class="v">${escapeHtml(appState.quotation.city || "")}</span></div>
            <div class="meta"><span class="k">Validez</span><span class="v">${escapeHtml(appState.quotation.validity || "")}</span></div>
            <div class="meta"><span class="k">Equipos</span><span class="v">${appState.items.length}</span></div>
          </div>
        </section>

        <div class="quote-summary">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Equipo</th>
                <th>Marca</th>
                <th>Modelo</th>
                <th>Precio</th>
              </tr>
            </thead>
            <tbody>
              ${appState.items.map((item, index) => `
                <tr>
                  <td>${index + 1}</td>
                  <td>${escapeHtml(item.title || "")}</td>
                  <td>${escapeHtml(item.brand || "")}</td>
                  <td>${escapeHtml(item.model || "")}</td>
                  <td>${escapeHtml(formatPrice(item.price || ""))}</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>

        <div class="total-box">
          <span class="label">Total referencial</span>
          <span class="value">Bs. ${total.toFixed(2)}</span>
        </div>

        <section class="card" style="margin-top:18px;">
          <h3 class="section-title">Condiciones generales</h3>
          <p class="preview-text"><strong>Forma de pago:</strong><br>${nl2br(appState.quotation.paymentTerms || "")}</p>
          <p class="preview-text"><strong>Observaciones:</strong><br>${nl2br(appState.quotation.notes || "")}</p>
        </section>

        <section class="footer-box">
          <div class="contact">
            <strong>BioSolutions</strong><br>
            Falsuri N° 155 entre Heroínas y Gral. Achá, Cochabamba - Bolivia<br>
            bio.solutions.bo@gmail.com<br>
            www.biosolutions.com.bo
          </div>
          <div class="sign">
            <div class="sign-line"></div>
            <strong>BioSolutions</strong><br>
            <span>Área Comercial</span>
          </div>
        </section>
      </div>
    </section>
  `;
}

function renderPreview() {
  const preview = document.getElementById("previewPages");
  if (!preview) return;

  const itemPages = appState.items.map(buildItemPage).join("");
  preview.innerHTML = itemPages + buildTotalPage();
}

function renderAll() {
  populateQuotationFields();
  renderItemsList();
  populateItemFields();
  renderEditors();
  renderPreview();
}

function saveJson() {
  const blob = new Blob([JSON.stringify(appState, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${appState.quotation.number || "cotizacion_biosolutions"}.json`;
  a.click();
}

function loadJsonFile(file) {
  const reader = new FileReader();
  reader.onload = () => {
    const data = JSON.parse(reader.result);
    appState.quotation = data.quotation || appState.quotation;
    appState.items = data.items || [];
    appState.selectedItemId = data.selectedItemId || (appState.items[0]?.id ?? null);

    if (appState.items.length === 0) addItem();
    else renderAll();
  };
  reader.readAsText(file);
}

function bindButtons() {
  document.getElementById("newQuotationBtn")?.addEventListener("click", resetQuotation);
  document.getElementById("addItemBtn")?.addEventListener("click", addItem);
  document.getElementById("duplicateItemBtn")?.addEventListener("click", duplicateSelectedItem);
  document.getElementById("deleteItemBtn")?.addEventListener("click", deleteSelectedItem);

  document.getElementById("addHighlightBtn")?.addEventListener("click", () => {
    const item = getSelectedItem();
    if (!item) return;
    item.highlights.push("Nueva característica");
    renderEditors();
    renderPreview();
  });

  document.getElementById("addSpecBtn")?.addEventListener("click", () => {
    const item = getSelectedItem();
    if (!item) return;
    item.specs.push({ param: "Parámetro", value: "Detalle" });
    renderEditors();
    renderPreview();
  });

  document.getElementById("addUseBtn")?.addEventListener("click", () => {
    const item = getSelectedItem();
    if (!item) return;
    item.uses.push("Nuevo uso");
    renderEditors();
    renderPreview();
  });

  document.getElementById("addAccessoryBtn")?.addEventListener("click", () => {
    const item = getSelectedItem();
    if (!item) return;
    item.accessories.push("Nuevo accesorio");
    renderEditors();
    renderPreview();
  });

  document.getElementById("addAdvantageBtn")?.addEventListener("click", () => {
    const item = getSelectedItem();
    if (!item) return;
    item.advantages.push("Nueva ventaja");
    renderEditors();
    renderPreview();
  });

  document.getElementById("saveJsonBtn")?.addEventListener("click", saveJson);
  document.getElementById("loadJsonBtn")?.addEventListener("click", () => {
    document.getElementById("jsonLoader")?.click();
  });

  document.getElementById("jsonLoader")?.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (file) loadJsonFile(file);
  });

  document.getElementById("printBtn")?.addEventListener("click", () => window.print());
}

function init() {
  bindQuotationFields();
  bindItemMainFields();
  bindButtons();
  addItem();
}

init();