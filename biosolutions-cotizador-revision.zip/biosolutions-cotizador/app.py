from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)
DB_PATH = "biosolutions.db"

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def index():
    conn = get_db_connection()

    equipos = conn.execute("""
        SELECT * FROM equipos
        WHERE activo = 1
        ORDER BY id DESC
    """).fetchall()

    plantillas = conn.execute("""
        SELECT p.*, e.nombre AS equipo_nombre, e.marca AS equipo_marca, e.modelo AS equipo_modelo
        FROM plantillas p
        JOIN equipos e ON e.id = p.equipo_id
        WHERE p.activo = 1
        ORDER BY p.id DESC
    """).fetchall()

    cotizaciones = conn.execute("""
        SELECT * FROM cotizaciones
        ORDER BY id DESC
    """).fetchall()

    conn.close()

    return render_template(
        "index.html",
        equipos=equipos,
        plantillas=plantillas,
        cotizaciones=cotizaciones
    )

@app.route("/equipos/nuevo", methods=["POST"])
def crear_equipo():
    nombre = request.form.get("nombre", "").strip()
    marca = request.form.get("marca", "").strip()
    modelo = request.form.get("modelo", "").strip()
    origen = request.form.get("origen", "").strip()
    garantia_base = request.form.get("garantia_base", "").strip()
    descripcion_breve = request.form.get("descripcion_breve", "").strip()
    descripcion_larga = request.form.get("descripcion_larga", "").strip()
    imagen = request.form.get("imagen", "").strip()

    if not nombre:
        return redirect(url_for("index"))

    conn = get_db_connection()
    conn.execute("""
        INSERT INTO equipos (
            nombre, marca, modelo, origen, garantia_base,
            descripcion_breve, descripcion_larga, imagen, activo
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
    """, (
        nombre,
        marca,
        modelo,
        origen,
        garantia_base,
        descripcion_breve,
        descripcion_larga,
        imagen
    ))
    conn.commit()
    conn.close()

    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8081, debug=True)